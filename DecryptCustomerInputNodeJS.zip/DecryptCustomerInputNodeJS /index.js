const AWS = require('aws-sdk');
const ssm = new AWS.SSM();
const { buildClient, CommitmentPolicy, RawRsaKeyringNode } = require('@aws-crypto/client-node');
const { decrypt } = buildClient(CommitmentPolicy.FORBID_ENCRYPT_ALLOW_DECRYPT);

const PARAM_PRIVATE_KEY = 'CONNECT_INPUT_DECRYPTION_KEY';
const PARAM_KEY_ID = 'CONNECT_INPUT_KEY_ID';

exports.handler = async(event) => {
    // console.log('From Connect ==>', JSON.stringify(event, null, 4));

    const privateKey = await getSSMParam(PARAM_PRIVATE_KEY);
    if (!privateKey) {
        return {
            statusCode: 500,
            body: "Missing Private Key",
        };
    }

    const keyId = await getSSMParam(PARAM_KEY_ID);
    if (!keyId) {
        return {
            statusCode: 500,
            body: "Missing keyId.  This is the KeyID From Amazon Connect",
        };
    }

    const keyNamespace = 'AmazonConnect'; // DO NOT CHANGE

    const rsaKey = {
        privateKey: privateKey
    };
    const keyring = new RawRsaKeyringNode({
        keyName: keyId,
        keyNamespace: keyNamespace,
        rsaKey: rsaKey,
        oaepHash: 'sha512'
    });

    const encryptedData = event.Details.ContactData.Attributes.EncryptedCreditCard;
    let decryptedData;
    if (encryptedData && encryptedData.length > 1) {
        const decryptedDataBytes = await decrypt(keyring, Buffer.from(encryptedData, 'base64'));
        decryptedData = decryptedDataBytes.plaintext.toString();

        console.log('The value entered is ' + decryptedData);
    }
    else {
        console.log("No data provided!");
        decryptedData = '';
    }

    const response = {
        statusCode: 200,
        body: decryptedData,
    };
    return response;
};

async function getSSMParam(name) {
    var params = {
        Name: name,
        WithDecryption: true
    };
    const data = await ssm.getParameter(params).promise();
    let value = '';
    if (data && data.Parameter) {
        value = data.Parameter.Value;
    }
    else {
        return null;
    }
    return value;
}
